#!/bin/bash
ping 8.8.8.8

